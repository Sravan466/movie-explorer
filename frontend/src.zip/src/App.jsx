// frontend/src/App.jsx
import React, { useState, useEffect } from 'react';
import MovieRow from './components/MovieRow';
import * as movieService from './services/movieService'; // Import all functions
import './App.css';

// Define which genres you want to display. Fetch their IDs first.
// Example: Action (28), Comedy (35), Horror (27)
const GENRE_IDS_TO_DISPLAY = [
  { id: 28, name: 'Action Thrills' },
  { id: 35, name: 'Comedy Central' },
  { id: 27, name: 'Spine-Chilling Horror' },
  // Add more genres as you like
];

function App() {
  const [popularMovies, setPopularMovies] = useState({ movies: [], isLoading: true });
  const [topRatedMovies, setTopRatedMovies] = useState({ movies: [], isLoading: true });
  const [upcomingMovies, setUpcomingMovies] = useState({ movies: [], isLoading: true });
  const [genreMovies, setGenreMovies] = useState([]); // Array of objects: {id, name, movies, isLoading}
  const [appError, setAppError] = useState(null);

  useEffect(() => {
    const fetchAllMovieData = async () => {
      try {
        setAppError(null);

        // Fetch standard categories
        const popularPromise = movieService.getPopularMovies().then(data => ({ movies: data.results.slice(0, 15), isLoading: false })); // Take first 15
        const topRatedPromise = movieService.getTopRatedMovies().then(data => ({ movies: data.results.slice(0, 15), isLoading: false }));
        const upcomingPromise = movieService.getUpcomingMovies().then(data => ({ movies: data.results.slice(0, 15), isLoading: false }));

        // Set loading states immediately for these
        setPopularMovies(prev => ({ ...prev, isLoading: true }));
        setTopRatedMovies(prev => ({ ...prev, isLoading: true }));
        setUpcomingMovies(prev => ({ ...prev, isLoading: true }));

        // Fetch genre movies
        // Initialize genreMovies state with isLoading true
        setGenreMovies(GENRE_IDS_TO_DISPLAY.map(genre => ({ ...genre, movies: [], isLoading: true })));

        const genrePromises = GENRE_IDS_TO_DISPLAY.map(async (genre) => {
          try {
            const data = await movieService.getMoviesByGenre(genre.id);
            return { ...genre, movies: data.results.slice(0, 15), isLoading: false };
          } catch (genreError) {
            console.error(`Error fetching movies for genre ${genre.name}:`, genreError);
            return { ...genre, movies: [], isLoading: false, error: true }; // Mark error for this genre
          }
        });

        // Resolve all promises
        const [popular, topRated, upcoming, ...resolvedGenreMovies] = await Promise.all([
          popularPromise,
          topRatedPromise,
          upcomingPromise,
          ...genrePromises
        ]);

        setPopularMovies(popular);
        setTopRatedMovies(topRated);
        setUpcomingMovies(upcoming);
        setGenreMovies(resolvedGenreMovies);

      } catch (error) {
        console.error("Failed to fetch movie data:", error);
        setAppError(error.message || "An error occurred while fetching data.");
        // Set all loading to false in case of a global error
        setPopularMovies({ movies: [], isLoading: false });
        setTopRatedMovies({ movies: [], isLoading: false });
        setUpcomingMovies({ movies: [], isLoading: false });
        setGenreMovies(prev => prev.map(g => ({ ...g, isLoading: false, error: true })));
      }
    };

    fetchAllMovieData();
  }, []);


  const handleMovieCardClick = (movieId) => {
    console.log("Movie card clicked:", movieId);
    // TODO: Implement navigation to movie detail page for this movieId
    // This will involve setting up React Router and a new MovieDetailPage component
  };

  const handleViewAll = (categoryTitle) => {
    console.log("View All clicked for:", categoryTitle);
    // TODO: Implement navigation to a category/genre page for this categoryTitle
    // This will also involve React Router and a new CategoryPage component
  };

  return (
    <div className="App">
      <header className="app-header">
        <h1>Movie Explorer</h1>
      </header>
      <main>
        {appError && <p style={{ color: 'red', textAlign: 'center' }}>Error: {appError}</p>}

        <MovieRow
          title="Popular Movies"
          movies={popularMovies.movies}
          isLoading={popularMovies.isLoading}
          onMovieClick={handleMovieCardClick}
          onViewAllClick={handleViewAll}
        />
        <MovieRow
          title="Top Rated Movies"
          movies={topRatedMovies.movies}
          isLoading={topRatedMovies.isLoading}
          onMovieClick={handleMovieCardClick}
          onViewAllClick={handleViewAll}
        />
        <MovieRow
          title="Upcoming Releases"
          movies={upcomingMovies.movies}
          isLoading={upcomingMovies.isLoading}
          onMovieClick={handleMovieCardClick}
          onViewAllClick={handleViewAll}
        />

        {genreMovies.map((genreRow) => (
          <MovieRow
            key={genreRow.id}
            title={genreRow.name}
            movies={genreRow.movies}
            isLoading={genreRow.isLoading}
            onMovieClick={handleMovieCardClick}
            onViewAllClick={() => handleViewAll(genreRow.name)} // Pass genre name or ID
          />
        ))}
      </main>
      <footer className="app-footer">
        <p>&copy; {new Date().getFullYear()} Movie Explorer. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;