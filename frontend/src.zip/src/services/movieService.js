// frontend/src/services/movieService.js
import axios from 'axios';

const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
export const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/'; // e.g., w500, original

// Axios instance for TMDB API with automatic API key attachment
const tmdbApi = axios.create({
  baseURL: TMDB_BASE_URL,
  params: {
    api_key: TMDB_API_KEY,
    language: 'en-US', // Optional: set default language
  },
});

// --- TMDB Specific Functions ---

export const getPopularMovies = async (page = 1) => {
  try {
    // Ensure your VITE_TMDB_API_KEY is set in .env and Vite is restarted
    if (!TMDB_API_KEY) throw new Error('TMDB API Key is not configured.');
    const response = await tmdbApi.get('/movie/popular', { params: { page } });
    return response.data;
  } catch (error) {
    console.error('Error fetching popular movies from TMDB:', error);
    throw error; // Re-throw to be caught by the component
  }
};

export const getTopRatedMovies = async (page = 1) => {
  try {
    if (!TMDB_API_KEY) throw new Error('TMDB API Key is not configured.');
    const response = await tmdbApi.get('/movie/top_rated', { params: { page } });
    return response.data;
  } catch (error) {
    console.error('Error fetching top-rated movies:', error);
    throw error;
  }
};

export const getUpcomingMovies = async (page = 1) => {
  try {
    if (!TMDB_API_KEY) throw new Error('TMDB API Key is not configured.');
    const response = await tmdbApi.get('/movie/upcoming', { params: { page } });
    return response.data;
  } catch (error) {
    console.error('Error fetching upcoming movies:', error);
    throw error;
  }
};

export const getMovieGenres = async () => {
  try {
    if (!TMDB_API_KEY) throw new Error('TMDB API Key is not configured.');
    const response = await tmdbApi.get('/genre/movie/list');
    return response.data.genres; // Returns an array of genre objects [{id, name}, ...]
  } catch (error) {
    console.error('Error fetching movie genres:', error);
    throw error;
  }
};

export const getMoviesByGenre = async (genreId, page = 1) => {
  try {
    if (!TMDB_API_KEY) throw new Error('TMDB API Key is not configured.');
    const response = await tmdbApi.get('/discover/movie', {
      params: {
        with_genres: genreId,
        page,
        sort_by: 'popularity.desc', // Optional: sort by popularity
      },
    });
    return response.data;
  } catch (error) {
    console.error(`Error fetching movies for genre ID ${genreId}:`, error);
    throw error;
  }
};

// Placeholder for your old local API function if you still need it for something else.
// If not, you can remove it.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5001/api';
const localApi = axios.create({
  baseURL: API_BASE_URL,
});

export const getAllMovies = async (page = 1) => {
  console.warn("getAllMovies from local API is deprecated for TMDB integration. Update App.jsx to use TMDB service if it's still being called.");
  try {
    // const response = await localApi.get('/movies', { params: { page } });
    // return response.data;
    return { results: [], page: 1, total_pages: 1 }; // Return empty for now
  } catch (error) {
    console.error('Error fetching all movies from local API:', error);
    throw error;
  }
};