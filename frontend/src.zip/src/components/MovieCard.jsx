// frontend/src/components/MovieCard.jsx
import React from 'react';
import { TMDB_IMAGE_BASE_URL } from '../services/movieService'; // Import base URL

const cardStyle = {
  border: '1px solid #ddd',
  borderRadius: '12px', // Slightly more rounded
  padding: '0', // Remove padding, image will be flush
  margin: '15px',
  width: '250px', // A common card width
  minHeight: '480px', // Ensure cards have a similar minimum height
  boxShadow: '0 6px 12px rgba(0,0,0,0.15)',
  backgroundColor: '#ffffff',
  textAlign: 'left', // Align text to left for a cleaner look
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden', // Ensure content respects border radius
  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
};

const cardHoverStyle = { // For potential hover effect, can be added via CSS class
  // transform: 'translateY(-5px)',
  // boxShadow: '0 12px 24px rgba(0,0,0,0.2)',
};

const posterStyle = {
  width: '100%',
  height: '375px', // Fixed height for poster
  objectFit: 'cover',
  borderTopLeftRadius: '12px', // Match card radius
  borderTopRightRadius: '12px',
  backgroundColor: '#e0e0e0', // Placeholder for missing posters
};

const contentStyle = {
  padding: '15px',
  flexGrow: 1, // Allows this section to take up remaining space
  display: 'flex',
  flexDirection: 'column',
}

const titleStyle = {
  fontSize: '1.1em', // Slightly smaller for card
  fontWeight: '600', // Bolder
  margin: '0 0 8px 0',
  lineHeight: '1.3',
  minHeight: '42px', // Approx 2 lines
  color: '#333',
};

const infoStyle = {
  fontSize: '0.85em',
  color: '#555',
  marginBottom: '5px',
};

const ratingStyle = {
  fontWeight: 'bold',
  color: '#e7a004', // Gold-ish color for rating
  marginTop: 'auto', // Push rating to the bottom of the content
  paddingTop: '8px',
}

function MovieCard({ movie }) {
  if (!movie) {
    return null;
  }

  const posterUrl = movie.poster_path
        ? `${TMDB_IMAGE_BASE_URL}w500${movie.poster_path}`
        : 'https://via.placeholder.com/500x750.png?text=No+Image';

  return (
    <div style={cardStyle} className="movie-card"> {/* Add className for CSS hover effects */}
      <img src={posterUrl} alt={`${movie.title} Poster`} style={posterStyle} />
      <div style={contentStyle}>
        <h3 style={titleStyle}>{movie.title || 'Untitled Movie'}</h3>
        {movie.release_date && (
          <p style={infoStyle}>Released: {new Date(movie.release_date).toLocaleDateString()}</p>
        )}
         {/* Overview can be added on a detail page or a "quick view" modal */}
        {/* <p style={{...infoStyle, flexGrow: 1, overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical' }}>
          {movie.overview || 'No overview available.'}
        </p> */}
        {movie.vote_average > 0 && (
          <p style={{...infoStyle, ...ratingStyle}}>
            Rating: {movie.vote_average.toFixed(1)} / 10
          </p>
        )}
      </div>
    </div>
  );
}

export default MovieCard;