// frontend/src/components/MovieRow.jsx
import React, { useRef, useState, useEffect } from 'react';
import MovieCard from './MovieCard';
import './MovieRow.css'; // Ensure this is imported

// You can use simple text arrows or import icons from a library later
const LeftArrowIcon = () => <>&larr;</>; // Simple left arrow
const RightArrowIcon = () => <>&rarr;</>; // Simple right arrow

function MovieRow({ title, movies, isLoading, onMovieClick, onViewAllClick }) { // Added onViewAllClick
  const scrollContainerRef = useRef(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(false);

  const handleScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 1); // -1 for precision
    }
  };

  useEffect(() => {
    const scrollElement = scrollContainerRef.current;
    if (scrollElement) {
      // Initial check
      handleScroll();
      // Add event listener
      scrollElement.addEventListener('scroll', handleScroll);
      // Check on window resize too, as clientWidth might change
      window.addEventListener('resize', handleScroll);

      // Cleanup
      return () => {
        scrollElement.removeEventListener('scroll', handleScroll);
        window.removeEventListener('resize', handleScroll);
      };
    }
  }, [movies]); // Re-check if movies change, as scrollWidth might change

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = scrollContainerRef.current.clientWidth * 0.8; // Scroll by 80% of visible width
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="movie-row">
        <div className="movie-row-header">
          <h2 className="movie-row-title">{title}</h2>
        </div>
        <p className="loading-text">Loading movies...</p>
      </div>
    );
  }

  if (!movies || movies.length === 0) {
    return null;
  }

  return (
    <div className="movie-row">
      <div className="movie-row-header">
        <h2 className="movie-row-title">{title}</h2>
        {/* "View All" button/link - functionality to be fully implemented later */}
        {movies.length > 5 && ( // Only show if there are enough movies to warrant a "view all"
          <button
            onClick={() => onViewAllClick && onViewAllClick(title)} // Pass title or a category ID
            className="view-all-button"
          >
            View All
          </button>
        )}
      </div>
      <div className="movie-row-content">
        {showLeftArrow && (
          <button
            className="scroll-arrow left-arrow"
            onClick={() => scroll('left')}
            aria-label="Scroll left"
          >
            <LeftArrowIcon />
          </button>
        )}
        <div className="movie-row-scrollable" ref={scrollContainerRef}>
          {movies.map((movie) => (
            <div
              key={movie.id}
              onClick={() => onMovieClick && onMovieClick(movie.id)} // Handle movie click
              role="button" // Make it behave like a button for accessibility
              tabIndex={0} // Make it focusable
              onKeyPress={(e) => { if (e.key === 'Enter' || e.key === ' ') onMovieClick && onMovieClick(movie.id)}} // Keyboard accessibility
            >
              <MovieCard movie={movie} />
            </div>
          ))}
        </div>
        {showRightArrow && (
          <button
            className="scroll-arrow right-arrow"
            onClick={() => scroll('right')}
            aria-label="Scroll right"
          >
            <RightArrowIcon />
          </button>
        )}
      </div>
    </div>
  );
}

export default MovieRow;